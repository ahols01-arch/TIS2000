package com.ahols.gmpowertrain;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter btAdapter;
    private BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;
    private TextView status, output, vehicleLabel;
    private final Object ioLock = new Object();
    private volatile boolean busy = false;
    private SharedPreferences prefs;
    private final StringBuilder sessionLog = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<Float> rpmHistory = new ArrayList<>();
    private final ArrayList<Float> coolantHistory = new ArrayList<>();
    private final ArrayList<Float> throttleHistory = new ArrayList<>();
    private boolean graphRunning = false;
    private String lastOutput = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("gm_powertrain_settings", MODE_PRIVATE);
        btAdapter = BluetoothAdapter.getDefaultAdapter();
        buildUi();
        if (btAdapter == null) setStatus("This phone does not report Bluetooth support.");
        else {
            setStatus("Not connected. Pair the ELM327 in Android Bluetooth settings first.");
            if (prefs.getBoolean("auto_reconnect", true)) handler.postDelayed(this::tryAutoReconnect, 700);
        }
        log("App started");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22, 20, 22, 28); root.setBackgroundColor(0xFFF3F5F7);
        TextView title = new TextView(this); title.setText("GM POWERTRAIN DIAGNOSTICS"); title.setTextSize(21); title.setTextColor(0xFF101820); title.setTypeface(null, 1); root.addView(title);
        TextView subtitle = new TextView(this); subtitle.setText("ELM327 • OBD-II diagnostics • Android"); subtitle.setTextSize(14); subtitle.setTextColor(0xFF536170); root.addView(subtitle);
        vehicleLabel = new TextView(this); vehicleLabel.setTextSize(14); vehicleLabel.setTextColor(0xFF34495E); vehicleLabel.setPadding(0,8,0,0); root.addView(vehicleLabel); updateVehicleLabel();
        status = new TextView(this); status.setTextSize(14); status.setTextColor(0xFF0D47A1); status.setPadding(0,12,0,10); root.addView(status);
        addButton(root, "Settings / adapter / protocol / refresh rate", v -> showSettings());
        addButton(root, "Connect / select Bluetooth adapter", v -> chooseDevice());
        addButton(root, "Read / identify vehicle", v -> runCommand("ATI\nATDP\n0100", "Adapter and supported OBD-II PIDs"));
        addButton(root, "Terminal — basic and advanced", v -> showTerminal());
        addButton(root, "Live dashboard / sensor tests", v -> readLiveData());
        addButton(root, "Live data graphs", v -> showGraphs());
        addButton(root, "Custom PID / command editor", v -> showCustomEditor());
        addButton(root, "Vehicle profiles", v -> editVehicleProfile());
        addButton(root, "GM module diagnostics / support check", v -> moduleDiagnostics());
        addButton(root, "Read stored trouble codes", v -> readCodes("03", "Stored trouble codes"));
        addButton(root, "Read pending trouble codes", v -> readCodes("07", "Pending trouble codes"));
        addButton(root, "Read permanent trouble codes", v -> readCodes("0A", "Permanent trouble codes"));
        addButton(root, "Read freeze-frame data", v -> runCommand("0200\n0202\n020C\n0205", "Freeze-frame snapshot (where supported)"));
        addButton(root, "Check readiness monitors", v -> runCommand("0101", "Emissions readiness monitors"));
        addButton(root, "Export / share diagnostic logs", v -> exportLogs());
        addButton(root, "Clear trouble codes", v -> confirmClear());
        TextView warning = new TextView(this); warning.setText("LIMITS & SAFETY\nGeneric OBD-II does not equal a full GM Tech 2. This app cannot promise all-module scanning, bidirectional actuator tests, security access, or module programming. Module checks below test standard OBD responses only. Custom commands can affect vehicle behavior; use read-only commands unless you understand the consequences. Do not use while driving."); warning.setTextSize(13); warning.setTextColor(0xFF7A2E00); warning.setPadding(12,14,12,14); warning.setBackgroundColor(0xFFFFF0E0); root.addView(warning);
        TextView outLabel = new TextView(this); outLabel.setText("DIAGNOSTIC OUTPUT"); outLabel.setTextColor(0xFF101820); outLabel.setTypeface(null,1); outLabel.setPadding(0,18,0,8); root.addView(outLabel);
        output = new TextView(this); output.setText("Connect an adapter, then choose a diagnostic function."); output.setTextSize(14); output.setTextColor(0xFF17212B); output.setPadding(14,14,14,14); output.setBackgroundColor(Color.WHITE); output.setTextIsSelectable(true); root.addView(output);
        scroll.addView(root); setContentView(scroll);
    }

    private void addButton(LinearLayout root, String label, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(14); b.setGravity(Gravity.CENTER_VERTICAL); b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 5; root.addView(b, lp);
    }
    private void setStatus(String s) { if (status != null) status.setText(s); log("STATUS: " + s); }
    private void showOutput(String s) { lastOutput = s; log(s); runOnUiThread(() -> { if (output != null) output.setText(s); }); }
    private void log(String s) { synchronized (sessionLog) { sessionLog.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())).append("  ").append(s).append("\n"); if (sessionLog.length() > 60000) sessionLog.delete(0, sessionLog.length()-60000); } }

    private boolean hasConnectPermission() { return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED; }
    private void chooseDevice() {
        if (btAdapter == null) { toast("Bluetooth is unavailable on this phone."); return; }
        if (Build.VERSION.SDK_INT >= 31 && !hasConnectPermission()) { requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 41); return; }
        if (!btAdapter.isEnabled()) { toast("Turn Bluetooth on in Android settings, then try again."); return; }
        try {
            Set<BluetoothDevice> paired = btAdapter.getBondedDevices(); ArrayList<BluetoothDevice> devices = new ArrayList<>(paired);
            if (devices.isEmpty()) { toast("No paired devices. Pair the ELM327 in Android Bluetooth settings first."); return; }
            String[] names = new String[devices.size()]; for (int i=0;i<devices.size();i++) names[i] = safeName(devices.get(i)) + "  (" + devices.get(i).getAddress() + ")";
            new AlertDialog.Builder(this).setTitle("Select paired adapter").setItems(names, (d, which) -> { prefs.edit().putString("adapter_mac", devices.get(which).getAddress()).apply(); connect(devices.get(which)); }).setNegativeButton("Cancel", null).show();
        } catch (SecurityException e) { toast("Bluetooth permission is required."); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) { super.onRequestPermissionsResult(requestCode, permissions, results); if (requestCode == 41 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) chooseDevice(); else if (requestCode == 41) toast("Bluetooth permission was not granted."); }
    private void tryAutoReconnect() {
        if (!prefs.getBoolean("auto_reconnect", true) || btAdapter == null || socket != null) return;
        if (Build.VERSION.SDK_INT >= 31 && !hasConnectPermission()) return;
        String mac = prefs.getString("adapter_mac", ""); if (mac.isEmpty() || !btAdapter.isEnabled()) return;
        try { connect(btAdapter.getRemoteDevice(mac)); } catch (Exception e) { log("Auto reconnect unavailable: " + e.getMessage()); }
    }
    private void connect(BluetoothDevice device) {
        setStatus("Connecting to " + safeName(device) + "…");
        new Thread(() -> {
            try {
                closeSocket(); BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP_UUID); s.connect(); socket=s; in=s.getInputStream(); out=s.getOutputStream();
                String proto = prefs.getString("protocol", "0"); String init = command("ATZ") + command("ATE0") + command("ATL0") + command("ATS0") + command("ATH0") + command("ATSP" + proto);
                runOnUiThread(() -> setStatus("Connected to " + safeName(device) + " • ELM initialized")); showOutput("Adapter connected. Initialization response:\n" + init + "\nProtocol setting: ATSP" + proto + "\nReady for OBD-II requests.");
            } catch (Exception e) { closeSocket(); runOnUiThread(() -> setStatus("Connection failed: " + e.getMessage())); }
        }).start();
    }
    private String safeName(BluetoothDevice d) { try { String n=d.getName(); return n==null?"Bluetooth adapter":n; } catch (Exception e) { return "Bluetooth adapter"; } }
    private void closeSocket() { try { if (socket != null) socket.close(); } catch(Exception ignored) {} socket=null; in=null; out=null; }

    private String command(String cmd) throws Exception {
        synchronized (ioLock) {
            if (socket == null || !socket.isConnected() || out == null || in == null) throw new Exception("Not connected. Connect your paired ELM327 first.");
            while (in.available() > 0) in.read(); out.write((cmd + "\r").getBytes(StandardCharsets.US_ASCII)); out.flush();
            StringBuilder response = new StringBuilder(); long end = System.currentTimeMillis() + prefs.getInt("timeout_ms", 2600);
            while (System.currentTimeMillis() < end) { if (in.available() > 0) { int c=in.read(); if(c>=0){ if(c=='>') break; response.append((char)c); } } else { if(response.length()>0){ Thread.sleep(120); if(in.available()==0) break; } else Thread.sleep(35); } }
            String result=response.toString().replace("\r","\n").trim(); log("> " + cmd + "\n" + result); return result;
        }
    }
    private void runCommand(String commands, String heading) {
        if (busy) { toast("A request is already running."); return; } busy=true; showOutput(heading + "\nWorking…");
        new Thread(() -> { StringBuilder sb=new StringBuilder(heading).append("\n\n"); try { for(String c:commands.split("\\n")) if(!c.trim().isEmpty()) sb.append("> ").append(c).append("\n").append(command(c.trim())).append("\n\n"); } catch(Exception e) { sb.append("ERROR: ").append(e.getMessage()); } showOutput(sb.toString()); busy=false; }).start();
    }
    private void readCodes(String mode, String heading) {
        if (busy) { toast("A request is already running."); return; } busy=true; showOutput(heading + "\nWorking…");
        new Thread(() -> { String result; try { result=command(mode); } catch(Exception e) { result="ERROR: "+e.getMessage(); } String parsed=decodeCodes(result,mode); showOutput(heading+"\nRaw response: "+result+"\n\n"+parsed); busy=false; }).start();
    }
    private String decodeCodes(String raw, String mode) {
        String clean=raw.toUpperCase().replaceAll("[^0-9A-F]", " ").trim(); String[] tokens=clean.split("\\s+"); ArrayList<Integer> bytes=new ArrayList<>();
        for(String t:tokens) if(t.matches("[0-9A-F]{2}")) try { bytes.add(Integer.parseInt(t,16)); } catch(Exception ignored) {}
        int expected=mode.equals("03")?0x43:mode.equals("07")?0x47:0x4A; int start=bytes.indexOf(expected);
        if(start>=0) { StringBuilder b=new StringBuilder(); int found=0; for(int i=start+1;i+1<bytes.size();i+=2){int a=bytes.get(i),c=bytes.get(i+1);if(a==0&&c==0)continue;b.append("• ").append(formatDtc(a,c)).append("\n");found++;} if(found>0)return b.toString();return "No codes reported in this response."; }
        if(raw.toUpperCase().contains("NO DATA")) return "No data returned. The vehicle may not support this mode, or the adapter may not be communicating with the ECU.";
        if(raw.toUpperCase().contains("UNABLE TO CONNECT")) return "Unable to connect to the vehicle ECU. Check ignition position, adapter compatibility, and vehicle protocol.";
        return "Could not reliably decode this adapter response. Check the raw response above.";
    }
    private String formatDtc(int a,int b){char[] first={'P','C','B','U'};int kind=(a>>6)&3,d1=(a>>4)&3,d2=a&15;return ""+first[kind]+d1+Integer.toHexString(d2).toUpperCase()+Integer.toHexString((b>>4)&15).toUpperCase()+Integer.toHexString(b&15).toUpperCase();}

    private String[][] pids() { return new String[][]{{"010C","Engine RPM"},{"0105","Coolant temperature"},{"010D","Vehicle speed"},{"0111","Throttle position"},{"0104","Calculated engine load"},{"0106","Short-term fuel trim bank 1"},{"0107","Long-term fuel trim bank 1"},{"010F","Intake air temperature"},{"010B","Intake manifold pressure"},{"010E","Ignition timing advance"}}; }
    private void readLiveData() {
        if (busy) { toast("A request is already running."); return; } busy=true; showOutput("LIVE POWERTRAIN DASHBOARD / SENSOR TESTS\nReading standard OBD-II PIDs…");
        new Thread(() -> { StringBuilder s=new StringBuilder("LIVE POWERTRAIN DASHBOARD / SENSOR TESTS\n\n"); try { for(String[] p:pids()) s.append(p[1]).append(": ").append(parsePid(p[0],command(p[0]))).append("\n"); } catch(Exception e) { s.append("\nERROR: ").append(e.getMessage()); } showOutput(s.toString()); busy=false; }).start();
    }
    private String parsePid(String pid,String raw) {
        String hex=raw.toUpperCase().replaceAll("[^0-9A-F]"," ").trim();String[] t=hex.split("\\s+");ArrayList<Integer>b=new ArrayList<>();for(String x:t)if(x.matches("[0-9A-F]{2}"))try{b.add(Integer.parseInt(x,16));}catch(Exception ignored){}
        int expected;try{expected=Integer.parseInt(pid.substring(2),16);}catch(Exception e){return raw;}int idx=-1;for(int i=0;i+1<b.size();i++)if(b.get(i)==0x41&&b.get(i+1)==expected){idx=i+2;break;}if(idx<0||idx>=b.size())return raw.toUpperCase().contains("NO DATA")?"Not supported / no data":raw;
        int a=b.get(idx),c=idx+1<b.size()?b.get(idx+1):0;switch(pid){case "010C":if(idx+1<b.size())return String.format(Locale.US,"%.0f rpm",(a*256+c)/4.0);break;case "0105":case "010F":return (a-40)+" °C ("+String.format(Locale.US,"%.0f",(a-40)*9/5.0+32)+" °F)";case "010D":return a+" km/h ("+String.format(Locale.US,"%.1f",a*0.621371)+" mph)";case "0111":case "0104":return String.format(Locale.US,"%.1f%%",a*100.0/255.0);case "0106":case "0107":return String.format(Locale.US,"%.1f%%",(a-128)*100.0/128.0);case "010B":return a+" kPa";case "010E":return String.format(Locale.US,"%.1f°",a/2.0-64);}return raw;
    }

    private void showSettings() {
        String[] opts={"Select Bluetooth adapter","Auto reconnect: "+(prefs.getBoolean("auto_reconnect",true)?"ON":"OFF"),"Protocol: "+prefs.getString("protocol","0"),"Refresh rate: "+prefs.getInt("refresh_ms",1000)+" ms","Command timeout: "+prefs.getInt("timeout_ms",2600)+" ms"};
        new AlertDialog.Builder(this).setTitle("Configuration").setItems(opts,(d,which)->{if(which==0)chooseDevice();else if(which==1){boolean v=!prefs.getBoolean("auto_reconnect",true);prefs.edit().putBoolean("auto_reconnect",v).apply();toast("Auto reconnect "+(v?"enabled":"disabled"));}else if(which==2)chooseProtocol();else if(which==3)chooseRefresh();else chooseTimeout();}).setNegativeButton("Close",null).show();
    }
    private void chooseProtocol(){String[] labels={"Automatic (0)","SAE J1850 VPW (2)","SAE J1850 PWM (1)","ISO 9141-2 (3)","ISO 14230-4 KWP (4)","CAN 11-bit 500k (6)","CAN 29-bit 500k (7)"};String[] vals={"0","2","1","3","4","6","7"};new AlertDialog.Builder(this).setTitle("OBD protocol").setItems(labels,(d,w)->{prefs.edit().putString("protocol",vals[w]).apply();toast("Protocol saved. Reconnect adapter to apply.");}).setNegativeButton("Cancel",null).show();}
    private void chooseRefresh(){String[] labels={"500 ms","1000 ms","1500 ms","2000 ms","3000 ms"};int[] vals={500,1000,1500,2000,3000};new AlertDialog.Builder(this).setTitle("Graph refresh rate").setItems(labels,(d,w)->prefs.edit().putInt("refresh_ms",vals[w]).apply()).setNegativeButton("Cancel",null).show();}
    private void chooseTimeout(){String[] labels={"1500 ms","2600 ms","4000 ms","6000 ms"};int[] vals={1500,2600,4000,6000};new AlertDialog.Builder(this).setTitle("Command timeout").setItems(labels,(d,w)->prefs.edit().putInt("timeout_ms",vals[w]).apply()).setNegativeButton("Cancel",null).show();}

    private void showTerminal(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,8,20,0);TextView hint=new TextView(this);hint.setText("Basic examples: ATI, ATDP, 010C, 0105, 03. Advanced mode sends raw ELM/OBD commands. One command per line. Avoid commands that change ECU settings.");box.addView(hint);EditText input=new EditText(this);input.setHint("Enter command(s), e.g. ATI or 010C");input.setMinLines(2);input.setGravity(Gravity.TOP);box.addView(input);String[] modes={"Basic","Advanced"};final int[] mode={1};Button modeBtn=new Button(this);modeBtn.setText("Mode: Advanced (tap to switch)");modeBtn.setOnClickListener(v->{mode[0]=1-mode[0];modeBtn.setText("Mode: "+modes[mode[0]]+" (tap to switch)");});box.addView(modeBtn);new AlertDialog.Builder(this).setTitle("ELM327 Terminal").setView(box).setPositiveButton("Send",(d,w)->{String text=input.getText().toString().trim();if(text.isEmpty())return;if(mode[0]==0)text=text.split("\\s+")[0];if(text.length()>300||!text.matches("(?i)[a-z0-9\\s\\r\\n]+")){toast("Use letters, numbers, and line breaks only.");return;}if(containsRestrictedCommand(text)){toast("This terminal blocks code clearing and write/control/programming services. Use the confirmed Clear Trouble Codes button for code clearing.");return;}runCommand(text.replace("\r",""),"Terminal response ("+modes[mode[0]]+")");}).setNeutralButton("Common commands",(d,w)->new AlertDialog.Builder(this).setTitle("Choose command").setItems(new String[]{"Adapter identity — ATI","Protocol — ATDP","Supported PIDs — 0100","Engine RPM — 010C","Coolant temperature — 0105","Stored codes — 03"},(x,n)->runCommand(new String[]{"ATI","ATDP","0100","010C","0105","03"}[n],"Terminal command")).show()).setNegativeButton("Cancel",null).show();}

    private boolean containsRestrictedCommand(String commands){for(String line:commands.split("\\n")){String c=line.replaceAll("\\s+","").toUpperCase(Locale.US);if(c.startsWith("AT"))continue;if(c.matches("04([0-9A-F]*)")||c.matches("08[0-9A-F]*")||c.matches("2E[0-9A-F]*")||c.matches("2F[0-9A-F]*")||c.matches("31[0-9A-F]*")||c.matches("3[4-7][0-9A-F]*"))return true;}return false;}

    private void showCustomEditor(){LinearLayout box=new LinearLayout(this);box.setPadding(20,8,20,0);box.setOrientation(LinearLayout.VERTICAL);TextView t=new TextView(this);t.setText("Custom standard PID: enter a two-digit PID in hexadecimal (e.g. 0C for RPM). Or use the raw command field for a documented ELM/OBD request. Unsupported PIDs may return NO DATA.");box.addView(t);EditText pid=new EditText(this);pid.setHint("PID hex, e.g. 0C");pid.setSingleLine(true);box.addView(pid);EditText raw=new EditText(this);raw.setHint("Optional raw command, e.g. ATDP");raw.setSingleLine(true);box.addView(raw);new AlertDialog.Builder(this).setTitle("Custom PID / command editor").setView(box).setPositiveButton("Run",(d,w)->{String custom=raw.getText().toString().trim();if(!custom.isEmpty()){if(!custom.matches("(?i)[a-z0-9]+")){toast("Command must contain letters/numbers only.");return;}if(containsRestrictedCommand(custom)){toast("Write/control/programming services are blocked in this starter build.");return;}runCommand(custom,"Custom command result");}else{String p=pid.getText().toString().trim();if(!p.matches("(?i)[0-9a-f]{2}")){toast("Enter a two-digit hexadecimal PID.");return;}runCommand("01"+p.toUpperCase(Locale.US),"Custom PID 01"+p.toUpperCase(Locale.US));}}).setNegativeButton("Cancel",null).show();}

    private void editVehicleProfile(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,8,20,0);EditText year=field(box,"Year",prefs.getString("year","1997"));EditText make=field(box,"Make",prefs.getString("make","GMC"));EditText model=field(box,"Model",prefs.getString("model","C1500"));EditText engine=field(box,"Engine",prefs.getString("engine","5.7L V8"));EditText trans=field(box,"Transmission",prefs.getString("transmission","Automatic"));EditText notes=field(box,"Notes / other vehicle profile",prefs.getString("profile_notes","2WD"));new AlertDialog.Builder(this).setTitle("Vehicle profile").setView(box).setPositiveButton("Save",(d,w)->{prefs.edit().putString("year",year.getText().toString()).putString("make",make.getText().toString()).putString("model",model.getText().toString()).putString("engine",engine.getText().toString()).putString("transmission",trans.getText().toString()).putString("profile_notes",notes.getText().toString()).apply();updateVehicleLabel();log("Vehicle profile updated");}).setNegativeButton("Cancel",null).show();}
    private EditText field(LinearLayout parent,String label,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(label);e.setText(value);parent.addView(e);return e;}
    private void updateVehicleLabel(){if(vehicleLabel!=null)vehicleLabel.setText(prefs.getString("year","1997")+" "+prefs.getString("make","GMC")+" "+prefs.getString("model","C1500")+" • "+prefs.getString("engine","5.7L V8")+" • "+prefs.getString("transmission","Automatic"));}

    private void moduleDiagnostics(){new AlertDialog.Builder(this).setTitle("GM module diagnostics").setMessage("This adapter/app currently supports standard OBD-II requests to the emissions powertrain ECU. The checks below do not scan every GM module. A 1997 GM truck may use GM-specific Class 2 / J1850 VPW diagnostics for enhanced access. ABS, airbag, body, transmission-enhanced data, actuator tests and programming require verified protocol support and suitable hardware.\n\nRun a standard OBD response/support check now?").setPositiveButton("Run support check",(d,w)->runCommand("ATDP\n0100\n0120\n0140","Standard OBD protocol / PID support check")).setNegativeButton("Cancel",null).show();}

    private void showGraphs(){if(busy){toast("A request is already running.");return;}rpmHistory.clear();coolantHistory.clear();throttleHistory.clear();graphRunning=true;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView note=new TextView(this);note.setText("Live samples from standard OBD-II PIDs. Keep vehicle stationary; graphs stop when this window closes.");box.addView(note);GraphView graph=new GraphView(this);box.addView(graph,new LinearLayout.LayoutParams(-1,500));AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Live data graphs").setView(box).setNegativeButton("Stop",(d,w)->graphRunning=false).create();dialog.setOnDismissListener(d->graphRunning=false);dialog.show();dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);sampleGraph(graph);}
    private void sampleGraph(GraphView graph){if(!graphRunning)return;if(busy){handler.postDelayed(()->sampleGraph(graph),500);return;}busy=true;new Thread(()->{try{String r=parseNumber(command("010C"),"010C");String c=parseNumber(command("0105"),"0105");String t=parseNumber(command("0111"),"0111");synchronized(rpmHistory){rpmHistory.add(Float.parseFloat(r));coolantHistory.add(Float.parseFloat(c));throttleHistory.add(Float.parseFloat(t));if(rpmHistory.size()>60){rpmHistory.remove(0);coolantHistory.remove(0);throttleHistory.remove(0);}}}catch(Exception e){log("Graph sample error: "+e.getMessage());}finally{busy=false;runOnUiThread(graph::invalidate);if(graphRunning)handler.postDelayed(()->sampleGraph(graph),prefs.getInt("refresh_ms",1000));}}).start();}
    private String parseNumber(String raw,String pid){String hex=raw.toUpperCase().replaceAll("[^0-9A-F]"," ").trim();String[] ts=hex.split("\\s+");ArrayList<Integer>b=new ArrayList<>();for(String x:ts)if(x.matches("[0-9A-F]{2}"))try{b.add(Integer.parseInt(x,16));}catch(Exception ignored){}int id=Integer.parseInt(pid.substring(2),16),i=-1;for(int k=0;k+1<b.size();k++)if(b.get(k)==0x41&&b.get(k+1)==id){i=k+2;break;}if(i<0||i>=b.size())throw new IllegalArgumentException("PID "+pid+" unavailable: "+raw);int a=b.get(i),c=i+1<b.size()?b.get(i+1):0;if(pid.equals("010C"))return Float.toString((a*256+c)/4f);if(pid.equals("0105"))return Float.toString(a-40);return Float.toString(a*100f/255f);}
    private class GraphView extends View {private final Paint p=new Paint(3);GraphView(Activity a){super(a);setBackgroundColor(Color.WHITE);}protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();p.setColor(0xFFCFD8DC);p.setStrokeWidth(1);for(int i=1;i<5;i++)c.drawLine(20,h*i/5,w-10,h*i/5,p);drawSeries(c,rpmHistory,0xFF1565C0,0,6000,h,w);drawSeries(c,coolantHistory,0xFFD84315,-20,130,h,w);drawSeries(c,throttleHistory,0xFF2E7D32,0,100,h,w);p.setTextSize(28);p.setColor(0xFF1565C0);c.drawText("RPM",24,32,p);p.setColor(0xFFD84315);c.drawText("Coolant °C",140,32,p);p.setColor(0xFF2E7D32);c.drawText("Throttle %",330,32,p);}private void drawSeries(Canvas c,ArrayList<Float>a,int color,float min,float max,float h,float w){synchronized(a){if(a.size()<2)return;p.setColor(color);p.setStrokeWidth(4);for(int i=1;i<a.size();i++){float x1=20+(w-35)*(i-1)/(Math.max(59,a.size()-1)),x2=20+(w-35)*i/(Math.max(59,a.size()-1));float y1=h-15-(a.get(i-1)-min)/(max-min)*(h-55),y2=h-15-(a.get(i)-min)/(max-min)*(h-55);c.drawLine(x1,y1,x2,y2,p);}}}}

    private void exportLogs(){String text; synchronized(sessionLog){text=sessionLog.toString();}if(text.trim().isEmpty())text="No session logs yet.";Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,"GM Powertrain Diagnostics session log");send.putExtra(Intent.EXTRA_TEXT,text+"\n\nLAST DIAGNOSTIC OUTPUT\n"+lastOutput);try{startActivity(Intent.createChooser(send,"Export diagnostic log"));}catch(Exception e){toast("Could not open Android share sheet.");}}
    private void confirmClear(){new AlertDialog.Builder(this).setTitle("Clear diagnostic trouble codes?").setMessage("Save codes and freeze-frame data first. Clearing can erase diagnostic evidence and reset emissions readiness. Continue only if you intend to clear them.").setNegativeButton("Cancel",null).setPositiveButton("Clear codes",(d,w)->runCommand("04","Clear trouble codes")).show();}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    @Override protected void onDestroy(){graphRunning=false;handler.removeCallbacksAndMessages(null);closeSocket();super.onDestroy();}
}

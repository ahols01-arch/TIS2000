# GM Powertrain Diagnostics — Android source project

Version 0.2.0. Native Android Java starter for Bluetooth Classic ELM327 adapters. This source has not been compiled or vehicle-tested in this environment. Build it with the included GitHub Actions workflow and test cautiously.

## Features
- Bluetooth Classic SPP connection to a previously paired ELM327 adapter; remembers adapter MAC and optionally reconnects.
- Configuration: adapter selection, auto reconnect, ELM protocol, graph refresh interval, command timeout.
- Adapter identification, stored/pending/permanent DTC requests, standard live PIDs, freeze-frame requests, readiness status, and confirmed clear-code request.
- Basic/advanced ELM terminal, standard custom PID editor, diagnostic session logging and Android share/export.
- Editable vehicle profile, standard OBD support checks, and live graphs for RPM, coolant temperature and throttle position.
- Graph and dashboard data are standard OBD-II PIDs only. Unsupported PIDs may show NO DATA.

## Important limits
This is not a replacement for GM Tech 2 / TIS2000. A generic ELM327 cannot promise all-module scans, all GM-enhanced data, actuator tests, security access or module programming. The GM module screen performs standard OBD protocol/PID support checks only; it does not claim to scan ABS, airbag, body or every transmission module. The custom command terminal can send raw commands: use only commands you understand and prefer read-only requests. Clearing codes erases diagnostic evidence and can reset readiness. Never use while driving.

## Bluetooth
Pair the adapter in Android Bluetooth settings before connecting. This build uses Bluetooth Classic Serial Port Profile (SPP); BLE-only or Wi-Fi adapters need a different transport implementation. Auto reconnect uses the last selected paired device and can be disabled in Settings.

## Build from an Android phone with GitHub Actions
The repository must have project files at the root (`app/`, `settings.gradle`, `build.gradle`). In GitHub, open Actions → Build debug APK → Run workflow. Download the artifact named `gm-powertrain-diagnostics-debug-apk` from the completed run, extract it, and install `app-debug.apk`. If a run fails, open the run and expand the failed build step to read the error.

## Test before relying on it
Verify Bluetooth connection and adapter identity first. Compare displayed readings against a known-good scan tool when possible. The simple response parser may not decode every clone/ECU response format. No GM-specific enhanced protocol, actuator, or programming capability is implied by this app.
